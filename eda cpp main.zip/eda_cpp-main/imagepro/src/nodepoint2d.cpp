/* implementation of the class NodePoint2D
 */