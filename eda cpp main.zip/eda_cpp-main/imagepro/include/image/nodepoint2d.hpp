/*
 Class NodePoint2D
*/

namespace image {
	class NodePoint2D{
	private:		
	public:		
	};
}
